
import torch.nn as nn
from transformers.modeling_outputs import TokenClassifierOutput
from transformers import PreTrainedModel

from models.config import DeNERConfig
from models.loss import ForgetLoss, SecondMaxLoss, SumLogLoss, SeparationLoss
from models.deConcept.linear import LinearDeNER

class BiLSTMDeNER(PreTrainedModel):
    def __init__(
        self, 
        config: DeNERConfig, 
    ):
        super(BiLSTMDeNER, self).__init__(config)

        self.hidden = nn.LSTM(config.hidden_size, config.hidden_size, batch_first=True)
        self.classifier = nn.Linear(config.hidden_size, config.num_labels)
        
    def forward(
        self,
        input_ids=None,
        attention_mask=None,
        token_type_ids=None,
        input_lengths=None,
        labels=None,
        **kwargs
    ):
        outputs = self._encoder(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
            # input_lengths=input_lengths,
            **kwargs
        )
        sequence_output = outputs[0]

        logits = self._head(sequence_output, token_type_ids)
        
        loss_fct = self.loss_func()

        loss = loss_fct(logits.view(-1, self.config.num_labels), labels.view(-1))

        return TokenClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )
    
class BiLSTMDeNERSumLogLoss(BiLSTMDeNER):
    loss_func = SumLogLoss

class BiLSTMDeNERSecondMaxLoss(BiLSTMDeNER):
    loss_func = SecondMaxLoss

class BiLSTMDeNERSeparationLoss(BiLSTMDeNER):
    loss_func = SeparationLoss

class BiLSTMNER(BiLSTMDeNER):
    loss_func = nn.CrossEntropyLoss
