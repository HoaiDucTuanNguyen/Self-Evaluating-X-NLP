# uncompyle6 version 3.9.1
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.8.8 | packaged by conda-forge | (default, Feb 20 2021, 15:50:57) 
# [Clang 11.0.1 ]
# Embedded file name: /Users/Na/Project/BioModels/src/utils/measures/compute_methods/influence_2.py
# Compiled at: 2024-01-01 16:10:00
# Size of source mod 2**32: 5224 bytes
import torch
from utils.measures.batch_manager import BatchManager
from utils.measures.compute_methods.abstract import Influence
from utils.measures.model_output_wrapper import ModelOutputWrapper

class Influence2(Influence):

    def compute(self, model_output_wrapper: ModelOutputWrapper, batch_manager: BatchManager):
        dener_pred_logits = model_output_wrapper.dener_pred_logits
        origin_pred_logits = model_output_wrapper.origin_pred_logits
        dener_pred_max_logits = model_output_wrapper.dener_pred_max_logits
        origin_pred_max_logits = model_output_wrapper.origin_pred_max_logits
        num_labels = dener_pred_logits.shape[2]
        seq_len = dener_pred_logits.shape[1]
        mask_pred_labels = dener_pred_max_logits != 0
        mask_origin_pred_labels = origin_pred_max_logits != 0
        diff_labels = mask_pred_labels != mask_origin_pred_labels
        diff_labels = diff_labels.unsqueeze(2).to(torch.int)
        same_labels = mask_pred_labels & mask_origin_pred_labels
        same_labels = same_labels.unsqueeze(2).to(torch.int)
        filter_dener_pred_logits = dener_pred_logits * diff_labels
        filter_origin_pred_logits = origin_pred_logits * diff_labels
        same_filter_dener_pred_logits = dener_pred_logits * same_labels
        same_filter_origin_pred_logits = origin_pred_logits * same_labels
        dener_pred_max_index = torch.argmax(filter_dener_pred_logits, dim=2)
        origin_pred_max_index = torch.argmax(filter_origin_pred_logits, dim=2)
        same_dener_pred_max_index = torch.argmax(same_filter_dener_pred_logits, dim=2)
        same_origin_pred_max_index = torch.argmax(same_filter_origin_pred_logits, dim=2)
        dener_pred_max_one_hot = torch.eye(num_labels)[dener_pred_max_index]
        origin_pred_max_one_hot = torch.eye(num_labels)[origin_pred_max_index]
        same_dener_pred_max_one_hot = torch.eye(num_labels)[same_dener_pred_max_index]
        same_origin_pred_max_one_hot = torch.eye(num_labels)[same_origin_pred_max_index]
        origin_pred_from_pred_max_value = filter_origin_pred_logits[dener_pred_max_one_hot == 1]
        origin_pred_from_origin_max_value = filter_origin_pred_logits[origin_pred_max_one_hot == 1]
        same_origin_pred_from_pred_max_value = same_filter_origin_pred_logits[same_origin_pred_max_one_hot == 1]
        pred_from_pred_max_value = filter_dener_pred_logits[dener_pred_max_one_hot == 1]
        pred_from_origin_pred_max_value = filter_dener_pred_logits[origin_pred_max_one_hot == 1]
        same_pred_from_pred_max_value = same_filter_dener_pred_logits[same_dener_pred_max_one_hot == 1]
        origin_pred_from_pred_max_value = origin_pred_from_pred_max_value.reshape(-1, seq_len)
        origin_pred_from_origin_max_value = origin_pred_from_origin_max_value.reshape(-1, seq_len)
        pred_from_pred_max_value = pred_from_pred_max_value.reshape(-1, seq_len)
        pred_from_origin_pred_max_value = pred_from_origin_pred_max_value.reshape(-1, seq_len)
        same_origin_pred_from_pred_max_value = same_origin_pred_from_pred_max_value.reshape(-1, seq_len)
        same_pred_from_pred_max_value = same_pred_from_pred_max_value.reshape(-1, seq_len)
        subtract_pred = torch.subtract(pred_from_pred_max_value, origin_pred_from_pred_max_value) / torch.max(origin_pred_from_pred_max_value, pred_from_pred_max_value)
        subtract_origin_pred = torch.subtract(origin_pred_from_origin_max_value, pred_from_origin_pred_max_value) / torch.max(origin_pred_from_origin_max_value, pred_from_origin_pred_max_value)
        same_subtract = torch.subtract(same_origin_pred_from_pred_max_value, same_pred_from_pred_max_value) / torch.max(same_origin_pred_from_pred_max_value, same_pred_from_pred_max_value)
        sub = (subtract_pred + subtract_origin_pred) / 2
        sub = torch.nan_to_num(sub, nan=0.0)
        same_subtract = torch.nan_to_num(same_subtract, nan=0.0)
        influences = (sub.sum(1) + same_subtract.sum(1)) / (diff_labels.squeeze(2).sum(dim=1) + same_labels.squeeze(2).sum(dim=1))
        influences = self._fill_nan(influences)
        self.assert_result(influences)
        return influences

# okay decompiling influence_2.cpython-38.pyc
