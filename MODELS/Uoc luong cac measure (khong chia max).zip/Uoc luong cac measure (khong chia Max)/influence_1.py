# uncompyle6 version 3.9.1
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.8.8 | packaged by conda-forge | (default, Feb 20 2021, 15:50:57) 
# [Clang 11.0.1 ]
# Embedded file name: /Users/Na/Project/BioModels/src/utils/measures/compute_methods/influence_1.py
# Compiled at: 2024-03-13 22:33:32
# Size of source mod 2**32: 1732 bytes
import pandas as pd, torch
from utils.measures.batch_manager import BatchManager
from utils.measures.compute_methods.abstract import Influence
from utils.measures.model_output_wrapper import ModelOutputWrapper

class Influence1(Influence):

    def compute(self, model_output_wrapper: ModelOutputWrapper, batch_manager: BatchManager):
        dener_pred_max_logits = model_output_wrapper.dener_pred_max_logits
        origin_pred_max_logits = model_output_wrapper.origin_pred_max_logits
        mask_dener_pred_labels = dener_pred_max_logits != 0
        mask_origin_pred_labels = origin_pred_max_logits != 0
        diff = mask_dener_pred_labels != mask_origin_pred_labels
        diff = diff.to(torch.int)
        diff = diff.sum(dim=1)
        size = torch.count_nonzero(dener_pred_max_logits, dim=1) + torch.count_nonzero(origin_pred_max_logits, dim=1)
        influences = diff / size
        influences = self._fill_nan(influences)
        self.assert_result(influences)
        return influences

# okay decompiling influence_1.cpython-38.pyc
