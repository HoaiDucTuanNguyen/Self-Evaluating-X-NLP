from typing import Dict
import torch
import torch.nn as nn
from transformers import AutoModel, PreTrainedModel
from transformers.modeling_outputs import TokenClassifierOutput

from models.config import MultitaskConfig, TaskConfig


class MultitaskModel(PreTrainedModel):
    config_class = MultitaskConfig
    
    def __init__(self, config: MultitaskConfig):
        super().__init__(config)

        self._encoder = AutoModel.from_pretrained(
            config.encoder_model_name, 
        )
        
        self.task_configs = config.task_configs

        self.task_heads = nn.ModuleDict({
            "srl": SrlHead(config.task_configs["srl"]),
            "ner": NerHead(config.task_configs["ner"])
        }) 

        # self.activation = nn.Softmax(-1)
        
    def forward(
        self,
        input_ids=None,
        attention_mask=None,
        token_type_ids=None,
        labels=None,
        task_name=None,
        **kwargs
    ):
        task_name = task_name if task_name is not None else "srl"

        task_config = self.task_configs[task_name]

        outputs = self._encoder(
            input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        sequence_output = outputs[0]
        
        logits = self.task_heads[task_name](sequence_output, token_type_ids)

        loss = None
        if labels is not None:
            loss_fct = nn.CrossEntropyLoss(reduce=None)
            loss = loss_fct(logits.view(-1, task_config["num_labels"]), labels.view(-1))

        return TokenClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )
    
    def inference(self, batch: dict):
        task_name = 'srl'

        outputs = self._encoder(
            input_ids=batch['input_ids'],
            attention_mask=batch['attention_mask'],
            token_type_ids=batch['token_type_ids'],
        )
        sequence_output = outputs[0]

        logits = self.task_heads[task_name].inference(sequence_output, batch['token_type_ids'])

        return TokenClassifierOutput(
            logits=logits,
            hidden_states=sequence_output,
        )
        
        
        
