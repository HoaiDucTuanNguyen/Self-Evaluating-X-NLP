# uncompyle6 version 3.9.1
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.8.8 | packaged by conda-forge | (default, Feb 20 2021, 15:50:57) 
# [Clang 11.0.1 ]
# Embedded file name: /Users/Na/Project/BioModels/src/utils/measures/compute_methods/relevance_2.py
# Compiled at: 2024-03-16 21:44:40
# Size of source mod 2**32: 3140 bytes
import torch
from utils.measures.compute_methods.abstract import Relevance
from utils.measures.batch_manager import BatchManager
from utils.measures.model_output_wrapper import ModelOutputWrapper

class Relevance2(Relevance):

    def compute(self, model_output_wrapper: ModelOutputWrapper, batch_manager: BatchManager):
        dener_pred_logits = model_output_wrapper.dener_pred_logits
        origin_pred_logits = model_output_wrapper.origin_pred_logits
        gold_pred_one_hot = torch.eye(dener_pred_logits.shape[2])[model_output_wrapper.labels]
        dener_pred_max_logits = model_output_wrapper.dener_pred_max_logits
        origin_pred_max_logits = model_output_wrapper.origin_pred_max_logits
        gold_max_logits = model_output_wrapper.labels
        batch_size = dener_pred_logits.shape[0]
        num_labels = dener_pred_logits.shape[2]
        seq_len = dener_pred_logits.shape[1]
        relevance = []
        for b in range(batch_size):
            total = 0
            for t in range(seq_len):
                value = 0
                y_gold = gold_max_logits[(b, t)]
                y_old = origin_pred_max_logits[(b, t)]
                y = dener_pred_max_logits[(b, t)]
                p_gold = gold_pred_one_hot[(b, t)]
                p_old = origin_pred_logits[(b, t)]
                p = dener_pred_logits[(b, t)]
                if y_gold == y_old and y_gold == y:
                    increase_part = (p_old[y_gold] - p[y_gold]) / torch.max(p_old[y_gold], p[y_gold])
                    value = increase_part
                else:
                    if y_gold == y_old and y_gold != y:
                        increase_part = (p_old[y_gold] - p[y_gold]) / torch.max(p_old[y_gold], p[y_gold])
                        decrease_part = (p[y] - p_old[y]) / torch.max(p[y], p_old[y])
                        value = 0.5 * (increase_part + decrease_part)
                    else:
                        if y_gold != y_old and y_gold == y:
                            increase_part = (p_old[y_gold] - p[y_gold]) / torch.max(p_old[y_gold], p[y_gold])
                            decrease_part = (p[y_old] - p_old[y_old]) / torch.max(p[y_old], p_old[y_old])
                            value = 0.5 * (increase_part + decrease_part)
                        else:
                            if y_gold != y_old:
                                if y_gold != y:
                                    increase_part = (p_old[y_gold] - p[y_gold]) / torch.max(p_old[y_gold], p[y_gold])
                                    decrease_before_dener_part = (p[y_old] - p_old[y_old]) / torch.max(p[y_old], p_old[y_old])
                                    decrease_after_dener_part = (p[y] - p_old[y]) / torch.max(p[y], p_old[y])
                                    value = 0.3333333333333333 * (increase_part + decrease_before_dener_part + decrease_after_dener_part)
                total += value
            else:
                relevance_per_sentence = total / seq_len
                relevance.append(relevance_per_sentence)

        else:
            relevance = torch.tensor(relevance)
            relevance = self._fill_nan(relevance)
            return relevance_per_sentence

# okay decompiling relevance_2.cpython-38.pyc
