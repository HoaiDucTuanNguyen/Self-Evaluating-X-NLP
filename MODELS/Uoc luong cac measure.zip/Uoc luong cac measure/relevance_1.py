# uncompyle6 version 3.9.1
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.8.8 | packaged by conda-forge | (default, Feb 20 2021, 15:50:57) 
# [Clang 11.0.1 ]
# Embedded file name: /Users/Na/Project/BioModels/src/utils/measures/compute_methods/relevance_1.py
# Compiled at: 2024-03-16 22:18:35
# Size of source mod 2**32: 1139 bytes
from utils.measures.compute_methods.abstract import Relevance
from utils.measures.batch_manager import BatchManager
from utils.measures.model_output_wrapper import ModelOutputWrapper
from utils.metric.srl import compute_metrics

class Relevance1(Relevance):

    def compute(self, model_output_wrapper: ModelOutputWrapper, batch_manager: BatchManager):
        label_vocab = model_output_wrapper._srl_class_manager._srl_vocab
        dener_logits = model_output_wrapper.dener_pred_logits
        origin_logits = model_output_wrapper.origin_pred_logits
        dener_labels = model_output_wrapper.dener_pred_max_logits
        origin_labels = model_output_wrapper.origin_pred_max_logits
        gold_labels = model_output_wrapper.labels
        dener_labels = dener_labels.detach().cpu().numpy().tolist()
        origin_labels = origin_labels.detach().cpu().numpy().tolist()
        gold_labels = gold_labels.detach().cpu().numpy().tolist()
        F1_p = compute_metrics((dener_logits, gold_labels), label_vocab)["f1"]
        F1_p_old = compute_metrics((origin_logits, gold_labels), label_vocab)["f1"]
        return F1_p - F1_p_old

# okay decompiling relevance_1.cpython-38.pyc
