import os
from abc import ABC, abstractmethod
from copy import deepcopy
from logging import getLogger
from multiprocessing import Pool, cpu_count
from typing import Dict, List
from torch.utils.data import DataLoader
from tqdm import tqdm
from transformers import (AutoModelForTokenClassification, AutoTokenizer,
                          DataCollatorForTokenClassification,
                          PreTrainedTokenizer)

from data.preprocessing.base_model_dataset.base_model_dataset import \
    BaseModelDataset
from data.preprocessing.base_model_dataset.multitask_dataset import \
    MultitaskBioDataset
from data.preprocessing.task_dataset.srl_dataset import SrlBioDataset
from data.preprocessing.task_dataset.task_dataset import Mode, Split, Task
from models.explain.abstracts import ExplainModel
from utils.measures.archivists.abstract import Archivist
from utils.measures.batch_manager import BatchManager
from utils.measures.compute_methods.abstract import ComputeMethod
from utils.measures.model_output_wrapper import ModelOutputWrapper
from utils.measures.savers.abstract import Saver
from utils.measures.srl_class_manager import SrlClassManager
from utils.others import get_database, store_measures
import logging
import sys

logger = getLogger(__name__)

class MeasureComputer(ABC):
    def __init__(self, explain_model: ExplainModel, base_model_dataset: BaseModelDataset, srl_dataset: SrlBioDataset) -> None:
        super().__init__()
        self._explain_model = explain_model
        self._dataset = base_model_dataset
        self._results = None

        self._compute_methods: List[ComputeMethod] = []
        self._archivists: List[Archivist] = []

        self._tokenizer = AutoTokenizer.from_pretrained(self._explain_model.base_model_name)
        self._data_collator = DataCollatorForTokenClassification(self._tokenizer)

        self._srl_dataset = srl_dataset

        self._srl_vectorizer = self._srl_dataset.label_vectorizer
        self._label_vocab = self._srl_vectorizer.label_vocab

        self._srl_class_manager = SrlClassManager(self._label_vocab)

    def add_compute_methods(self, compute_methods: List[ComputeMethod]):
        for compute_method in compute_methods:
            compute_method.set_measure_computer(self)

        self._compute_methods.extend(compute_methods)

    def add_archivists(self, archivists: List[Archivist]):
        compute_method_names = [compute_method.__class__.__name__ for compute_method in self._compute_methods]

        for archivist in archivists:
            archivist.set_srl_class_manager(self._srl_class_manager)
            archivist.set_compute_methods(compute_method_names)

        self._archivists.extend(archivists)
        
    def compute_for_batch(self, batch_manager: BatchManager, srl_class: str) -> dict:
        local_srl_class_manager = deepcopy(self._srl_class_manager)
        local_srl_class_manager.set_current_class(srl_class)

        model_output_wrapper = ModelOutputWrapper(self._explain_model, local_srl_class_manager)

        model_output_wrapper.inference(batch_manager.get_current_batch(), srl_class)

        batch_measures = {}
        for compute_method in self._compute_methods:
            batch_measures[compute_method.__class__.__name__] = compute_method.compute(
                model_output_wrapper,
                batch_manager
            )

        return batch_measures

    def _process_srl_class(self, srl_class):

        filter_srl_dataset_dict = self._dataset.filter_by_class(srl_class)
        filter_srl_dataset = filter_srl_dataset_dict[Split.TEST]

        if len(filter_srl_dataset) == 0:
            raise ValueError(f"{srl_class} has no test data")

        test_dataloader = DataLoader(
            filter_srl_dataset, shuffle=False, batch_size=64, collate_fn=self._data_collator)

        num_batch = len(test_dataloader)

        batch_manager = BatchManager()

        batch_measures_list = []
        batch_info_list = []
        for batch_i, batch in enumerate(test_dataloader):
            batch_manager.set_current_batch_index(batch_i)
            batch_manager.set_current_batch(batch)

            # new batch
            batch_measures = self.compute_for_batch(batch_manager, srl_class)
            
            batch_measures_list.append(batch_measures)
            batch_info_list.append(batch)

        return srl_class, batch_measures_list, batch_info_list

        # merge batch measures
        # for batch_measures in batch_measures_list:
        

            # add batch measures to archivists                
        #     for archivist in self._archivists:
        #         archivist.append(batch_measures)

        # for archivist in self._archivists:
        #     archivist.mean()

        return 

    @abstractmethod
    def compute(self):
        pass

    def save(self, saver: Saver):
        saver.save(self._results, self._explain_model)


class MultiProcessComputer(MeasureComputer):
    def __init__(self, explain_model: ExplainModel, base_model_dataset: BaseModelDataset, srl_dataset: SrlBioDataset) -> None:
        super().__init__(explain_model, base_model_dataset, srl_dataset)
        self._num_proc = 1
        self._pbar_color = None
        

    def set_num_proc(self, percent_cpu_to_use: float = 0.3):
        '''
        Set the number of processes to use for parallel computing.
        If num_proc is "all", then use all available processes.
        '''
        num_proc = int(cpu_count() * percent_cpu_to_use)

        self._num_proc = num_proc

        return self
    
    def set_pbar_color(self, pbar_color: str):
        self._pbar_color = pbar_color

        return self
    
    def compute(self):
        # a computation has been commenced
        srl_class_list = [srl_class for srl_class in self._srl_class_manager.get_class_list()]

        # display dener model name
        print(f"{self._explain_model.dener_model_name}")

        with Pool(processes=self._num_proc) as pool:
            with tqdm(
                total=len(srl_class_list), 
                desc=f"{self.__class__.__name__} (num_proc={self._num_proc})", 
                colour=self._pbar_color
            ) as pbar:
                
                results = pool.imap_unordered(
                    self._process_srl_class, srl_class_list
                )

                for srl_class, batch_measures_list, batch_info_list in results:
                    if batch_measures_list is None:
                        raise Exception("batch_measures_list is None")
                    
                    self._srl_class_manager.set_current_class(srl_class)

                    for batch_measures, batch_info in zip(batch_measures_list, batch_info_list):
                        for archivist in self._archivists:
                            archivist.append(batch_measures, batch_info)

                    pbar.update()

                for archivist in self._archivists:
                    archivist.mean()

        results = {
            archivist.__class__.__name__: archivist.get_results() for archivist in self._archivists
        }
        self._results = results

        return results
    


        
