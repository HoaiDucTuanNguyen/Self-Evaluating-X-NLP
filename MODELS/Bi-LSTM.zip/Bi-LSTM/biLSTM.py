import torch.nn as nn
from transformers import AutoModel, PreTrainedModel
from transformers.modeling_outputs import TokenClassifierOutput
import torch
from models.config import BiLSTMConfig

class BiLSTM(PreTrainedModel):
    config_class = BiLSTMConfig

    def __init__(self, config: BiLSTMConfig):
        super().__init__(config)
        self._encoder = Encoder(config)

        self.fc = nn.Linear(config.hidden_dim, config.num_labels)
        self.activation = nn.LogSoftmax(dim=-1)
        
    def forward(self, input_ids, input_lengths=None, token_type_ids=None, labels=None, **kwargs):
        output = self._encoder(input_ids, input_lengths, token_type_ids)
        repr_vecs = output.logits


        outputs = self.fc(repr_vecs)
        outputs = self.activation(outputs)

        loss = None
        if labels is not None:
            loss_fct = nn.CrossEntropyLoss()
            loss = loss_fct(
                outputs.view(-1, self.config.num_labels), labels.view(-1))
            
        return TokenClassifierOutput(
            loss=loss,
            logits=outputs,
        )
    
    def inference(self, batch: dict):
        output = self._encoder(
            input_ids=batch['input_ids'], 
            input_lengths=batch['input_lengths'], 
            token_type_ids=batch['token_type_ids']
        )
        repr_vecs = output.logits

        outputs = self.fc(repr_vecs)

        outputs = nn.functional.softmax(outputs, dim=-1)
        
        return TokenClassifierOutput(
            logits=outputs,
            hidden_states=repr_vecs,
        )
