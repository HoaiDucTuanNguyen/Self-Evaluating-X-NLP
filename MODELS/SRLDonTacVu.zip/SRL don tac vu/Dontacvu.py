import torch.nn as nn
import torch
import math
from transformers import AutoModel, TrainingArguments, Trainer, PreTrainedModel, PretrainedConfig, AutoConfig
from transformers.modeling_outputs import TokenClassifierOutput
from utils.vecterizer import LabelVectorizer

class SRLModel(PreTrainedModel):
    config_class = AutoConfig
    
    def __init__(self, config: AutoConfig):
        super(SRLModel, self).__init__(config)
        
        self._encoder = AutoModel.from_pretrained(
            config.encoder_model_name, 
        )

        self.crf = nn.Linear(config.hidden_size, config.num_labels)

        self.activation = nn.LogSoftmax(dim=-1)
        
    def forward(
        self,
        input_ids=None,
        attention_mask=None,
        token_type_ids=None,
        head_mask=None,
        labels=None,
        **kwargs
    ):      
        outputs = self._encoder(
            attention_mask=attention_mask,
            input_ids=input_ids,
            token_type_ids=token_type_ids,
        )
        sequence_output = outputs[0]

        logits = self.crf(sequence_output)

        logits = self.activation(logits)

        if labels is not None:
            loss_fct = nn.CrossEntropyLoss(reduce=None)
            loss = loss_fct(logits.view(-1, self.config.num_labels), labels.view(-1))

        return TokenClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )
    
    def inference(self, batch: dict):
        outputs = self._encoder(
            input_ids=batch['input_ids'],
            attention_mask=batch['attention_mask'],
            token_type_ids=batch['token_type_ids'],
        )
        sequence_output = outputs[0]

        logits = self.crf(sequence_output)

        logits = nn.functional.softmax(outputs.logits, dim=-1)

        return TokenClassifierOutput(
            logits=logits,
            hidden_states=sequence_output,
        )


    